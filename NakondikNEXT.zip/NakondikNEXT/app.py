
from flask import Flask, render_template, request
import openai
import os

app = Flask(__name__)
openai.api_key = os.getenv("OPENAI_API_KEY")

SYSTEM_PROMPT = "Ты трэшовый ИИ по имени NakondikNEXT Ai. Отвечай дерзко, агрессивно, добавляй мемы и стикеры в стиле 18+ трэш-рэпа."

@app.route("/", methods=["GET", "POST"])
def index():
    reply = ""
    if request.method == "POST":
        user_input = request.form["message"]
        response = openai.ChatCompletion.create(
            model="gpt-3.5-turbo",
            messages=[
                {"role": "system", "content": SYSTEM_PROMPT},
                {"role": "user", "content": user_input}
            ]
        )
        reply = response['choices'][0]['message']['content']
    return render_template("index.html", reply=reply)

if __name__ == "__main__":
    app.run(debug=True)
